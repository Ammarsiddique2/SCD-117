
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>OX Cash </title>
<link rel="shortcut icon" href="assets/images/logo/favicon-logo.png?updated=1665123464">

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700%7COswald:300,400,500,600,700" rel="stylesheet" type="text/css">

<link href="assets/css/plugins.css?updated=1665123464" rel="stylesheet" type="text/css">
<link href="assets/css/style.css?updated=1665123464" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
<link rel="stylesheet" href="assets/css/style.min.css?updated=1665123464">

<script async src="https://www.googletagmanager.com/gtag/js?id=G-N10ZQHCXPP"></script>
<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'G-N10ZQHCXPP');
	</script>
</head>
<body class="loader">

<div class="loading">
<img class="logo-loading" src="assets/images/logo/favicon-logo.png?updated=1665123464" alt="logo">
</div>

<div class="pointer" id="pointer">
<i class="fas fa-long-arrow-alt-right"></i>
<i class="fas fa-search"></i>
<i class="fas fa-link"></i>
</div>

<a class="to-top-btn pointer-small" href="#up">
<span class="to-top-arrow"></span>
</a>

<header class="fixed-header">

<div class="header-flex-box">

<a href="index.php" class="logo pointer-large animsition-link">
<div class="logo-img-box">
<img class="logo-white" src="assets/images/logo/oxcash-logo.png" alt="logo">
<img class="logo-black" src="assets/images/logo/oxcash-logo.png" alt="logo">
</div>
</a>



</div>
</header>

<nav class="nav-container dark-bg-1">

<div class="nav-logo">
<img src="assets/images/logo/oxcash-logo.png" alt="logo">
</div>

<div class="menu-close pointer-large"></div>

<div class="dropdown-close-box">
<div class="dropdown-close pointer-large">
<span></span>
</div>
</div>

<ul class="nav-menu dark-bg-1">

<li class="nav-box nav-bg-change active dropdown-open">
<a class="pointer-large nav-link">
<span class="nav-btn" data-text="Login">Login</span>
</a>
<div class="nav-bg" style="background-image: url(assets/images/backgrounds/pexels-photo-1806031.jpg);"></div>
</li>
<li class="nav-box nav-bg-change active dropdown-open">
<a class="pointer-large nav-link">
<span class="nav-btn " data-text="Signup">Signup</span>
</a>
<div class="nav-bg" style="background-image: url(assets/images/backgrounds/pexels-photo-1806031.jpg);"></div>
</li>
<li class="nav-box nav-bg-change active dropdown-open">
<a class="pointer-large nav-link" href="" download>
<span class="nav-btn " data-text="Official Presentation">Official Presentation</span>
</a>
<div class="nav-bg" style="background-image: url(assets/images/backgrounds/pexels-photo-1806031.jpg);"></div>
</li>
</ul>
</nav>

<main class="animsition-overlay" data-animsition-overlay="true">

<section class="hero-section dark-bg-1 top-bottom-padding-120 position-relative" data-animation-container id="up" style="overflow: hidden;">

<video loop name="media" class="hero-bg" autobuffer autoplay playsinline muted>
<source src="assets/images/backgrounds/video/hero-bg.mp4?updated=1665123465" type="video/mp4">
</video>
<div class="container position-relative">
<div class="hero-animation">
<div class="hero-img position-relative text-center">
<img src="assets/images/backgrounds/hero-round.png?updated=1665123465" class="spin-animation" alt="">
<img src="assets/images/logo/favicon-logo.png?updated=1665123465" class="hero-logo" alt="">
</div>
</div>
<div data-animation-container="" class="text-center animated top-margin-30">
<h2 data-animation-child="" class="large-title text-color-4 overlay-anim-box2 animated overlay-anim2" data-animation="overlay-anim2">World's Largest Networking Protocol on TRON Blockchain!</h2>
</div>
<div class="hero-btn-group top-margin-30">
<div data-animation-child class="arrow-btn-box content-left-right-margin-5 top-bottom-margin-5" data-animation="fade-anim">
<a href="https://ox.cash/user/registration" class="arrow-btn pointer-large animsition-link  position-relative">Register</a>
</div>
<div class="border-btn-box border-btn-red pointer-large content-left-right-margin-5 top-bottom-margin-5">
<div class="border-btn-inner">
<a href="https://ox.cash/user/" class="border-btn" data-text="Login">Login</a>
</div>
</div>
<div class="arrow-btn-box slider-tr-delay06 content-left-right-margin-5 top-bottom-margin-5">
<a href="javascript:void(0);" class="arrow-btn pointer-large dropdown-toggle">Official Presentation</a>
<ul class="dropdown-box pointer-large">
<li><a href="assets/images/admin/1654154369OX Cash- Updated New PDF Verson.pdf" download class="pointer-large">English</a></li>
<li><a href="assets/images/admin/1654437570OX Cash- Updated New V3.pdf" download class="pointer-large">Hindi</a></li>
<li><a href="assets/images/admin/1654154597OX Cash- V.3.pdf" download class="pointer-large">French</a></li>
</ul>
</div>
</div>
</div>
</section>


<section class="home-slider" id="up" hidden>

<div class="swiper-wrapper">

<div class="swiper-slide flex-min-height-box home-slide">

<div class="slide-bg overlay-loading2 overlay-dark-bg-1" style="background-image:url(assets/images/admin/1651344606web-1-03.jpg)"></div>

<div class="home-slider-content flex-min-height-inner dark-bg-1">

<div class="container top-bottom-padding-120 flex-container response-999">

<div class="six-columns six-offset">
<div class="content-left-margin-40">
<h2 class="large-title-bold">
<span class="slider-title-fill slider-tr-delay01" data-text="smart contract">smart contract</span><br>
</h2>
<p class="p-style-bold-up text-height-20 d-flex-wrap">
<span class="slider-title-fill slider-tr-delay04" data-text="The worldwide progressive technology.">The worldwide progressive technology.</span>
</p>
</div>
</div>
</div>
</div>
</div>

</div>

<div class="swiper-button-next">
<div class="slider-arrow-next-box">
<span class="slider-arrow-next"></span>
</div>
</div>

<div class="swiper-button-prev">
<div class="slider-arrow-prev-box">
<span class="slider-arrow-prev"></span>
</div>
</div>

<div class="swiper-pagination"></div>

<a href="#down" class="scroll-btn pointer-large">
<div class="scroll-arrow-box">
<span class="scroll-arrow"></span>
</div>
<div class="scroll-btn-flip-box">
<span class="scroll-btn-flip" data-text="Scroll">Scroll</span>
</div>
</a>
</section>

<section id="down" class="dark-bg-1 welcome-section flex-min-height-box">

<div class="flex-min-height-inner">

<div class="container small top-bottom-padding-120">

<div data-animation-container class="flex-container">

<div class="twelve-columns text-center">
<h2 class="large-title text-height-12">
<span data-animation-child class="title-fill" data-animation="title-fill-anim" data-text="Welcome to OXCash">Welcome to OXCash</span><br>
</h2>
</div>

<div class="twelve-columns text-center">
<div class="content-right-margin-20">
<p data-animation-child class="p-style-medium text-color-5 fade-anim-box tr-delay02" data-animation="fade-anim">OXCASH is the worldwide local area network for decentralized environment and the very first Tron brilliant agreement promoting grid. Our Decentralized Networking Platform based on smart contracts that connects people from all over the world and opens the limitless possibilities of the new economic financial system</p>
</div>
</div>


</div>
</div>
</div>
</section>

<section class="latest-news top-padding-50 bottom-padding-50 light-bg-1" data-midnight="black">

<div class="container">

<div data-animation-container class="text-center bottom-margin-30">
<h2 data-animation-child class="large-title text-height-10 text-color-1 overlay-anim-box2" data-animation="overlay-anim2">Videos</h2><br>
</div>
<article class="content-right-margin-20" data-animation-container>
<div data-animation-container="" class="container small text-center animated bottom-margin-15">
<div href="https://www.youtube.com/watch?v=NBBJikcDCUE" target="_blank" data-animation-child="" class="p-style-bold overlay-anim-box2 animated overlay-anim2" data-animation="title-fill-anim" data-text="OXCASH Business Plan- English">OXCASH Business Plan- English</div>
<a href="https://www.youtube.com/watch?v=NBBJikcDCUE" target="_blank" rel="noopener noreferrer" class="p-style-bold d-block title-fill animated title-fill-anim" data-animation="title-fill-anim" data-text="Click Here">Click Here</a>
</div>
</article>
</div>
</section>
<div class="results">
<div class="section">
<div class="container">

<div data-animation-container class="container small bottom-padding-60 text-center">
<h2 data-animation-child class="large-title text-height-10 text-color-1 overlay-anim-box2" data-animation="overlay-anim2">Partner's results</h2><br>
<p data-animation-child class="fade-anim-box tr-delay02 text-color-1 xsmall-title-oswald top-margin-5" data-animation="fade-anim">All data is stored in the blockchain and can be verified by clicking on the smart contract address</p>
</div>
<div class="row">
<div class="col-lg-1 el-desc results-slider-btn-wrapper">
<button class="results-slider-btn results-slider-btn-prev">
<svg width="28" height="54" viewBox="0 0 28 54" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292893 26.2929C-0.0976311 26.6834 -0.097631 27.3166 0.292893 27.7071L26.2929 53.7071C26.6834 54.0976 27.3166 54.0976 27.7071 53.7071C28.0976 53.3166 28.0976 52.6834 27.7071 52.2929L1.70711 26.2929C1.31658 25.9024 0.683417 25.9024 0.292893 26.2929Z" fill="white" />
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292894 27.7071C0.683419 28.0976 1.31658 28.0976 1.70711 27.7071L27.7071 1.70711C28.0976 1.31658 28.0976 0.683416 27.7071 0.292892C27.3166 -0.0976323 26.6834 -0.0976323 26.2929 0.292892L0.292894 26.2929C-0.0976299 26.6834 -0.0976299 27.3166 0.292894 27.7071Z" fill="white" />
</svg>
</button>
</div>
<div class="col-lg-10">
<div class="slider owl-carousel">
<div class="slider-item eth-item">
<div class="slider-item-content">
<div class="slider-item__info">

<img src="assets/images/logo/favicon-logo.png?updated=1665123465" width="120" alt="">
<div class="slider-item__info-text">
<div class="slider-item__info-id">ID 1</div>
<div class="slider-item__info-users">
<i class="icon-partners icon-left"></i> 665 </div>
</div>
</div>
<div class="slider-item-stats">
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in USD</div>
<div class="slider-item__block-info">$ 1035171.65</div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in TRX</div>
<div class="slider-item__block-info">12178490 <span>TRX</span></div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Registration date</div>
<div class="slider-item__block-info">25-04-2022</div>
</div>
</div>
</div>
</div>
<div class="slider-item eth-item">
<div class="slider-item-content">
<div class="slider-item__info">

<img src="assets/images/logo/favicon-logo.png?updated=1665123465" width="120" alt="">
<div class="slider-item__info-text">
<div class="slider-item__info-id">ID 1218</div>
<div class="slider-item__info-users">
<i class="icon-partners icon-left"></i> 151 </div>
</div>
</div>
<div class="slider-item-stats">
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in USD</div>
<div class="slider-item__block-info">$ 768199.4</div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in TRX</div>
<div class="slider-item__block-info">9037640 <span>TRX</span></div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Registration date</div>
<div class="slider-item__block-info">12-09-2022</div>
</div>
</div>
</div>
</div>
<div class="slider-item eth-item">
<div class="slider-item-content">
<div class="slider-item__info">

<img src="assets/images/logo/favicon-logo.png?updated=1665123465" width="120" alt="">
<div class="slider-item__info-text">
<div class="slider-item__info-id">ID 352</div>
<div class="slider-item__info-users">
<i class="icon-partners icon-left"></i> 24 </div>
</div>
</div>
<div class="slider-item-stats">
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in USD</div>
<div class="slider-item__block-info">$ 288534.2</div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in TRX</div>
<div class="slider-item__block-info">3394520 <span>TRX</span></div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Registration date</div>
<div class="slider-item__block-info">11-09-2022</div>
</div>
</div>
</div>
</div>
<div class="slider-item eth-item">
<div class="slider-item-content">
<div class="slider-item__info">

<img src="assets/images/logo/favicon-logo.png?updated=1665123465" width="120" alt="">
<div class="slider-item__info-text">
<div class="slider-item__info-id">ID 357</div>
<div class="slider-item__info-users">
<i class="icon-partners icon-left"></i> 18 </div>
</div>
</div>
<div class="slider-item-stats">
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in USD</div>
<div class="slider-item__block-info">$ 220864.85</div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in TRX</div>
<div class="slider-item__block-info">2598410 <span>TRX</span></div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Registration date</div>
<div class="slider-item__block-info">11-09-2022</div>
</div>
</div>
</div>
</div>
<div class="slider-item eth-item">
<div class="slider-item-content">
<div class="slider-item__info">

<img src="assets/images/logo/favicon-logo.png?updated=1665123465" width="120" alt="">
<div class="slider-item__info-text">
<div class="slider-item__info-id">ID 1876</div>
<div class="slider-item__info-users">
<i class="icon-partners icon-left"></i> 44 </div>
</div>
</div>
<div class="slider-item-stats">
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in USD</div>
<div class="slider-item__block-info">$ 208391.1</div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in TRX</div>
<div class="slider-item__block-info">2451660 <span>TRX</span></div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Registration date</div>
<div class="slider-item__block-info">12-09-2022</div>
</div>
</div>
</div>
</div>
<div class="slider-item eth-item">
<div class="slider-item-content">
<div class="slider-item__info">

<img src="assets/images/logo/favicon-logo.png?updated=1665123465" width="120" alt="">
<div class="slider-item__info-text">
<div class="slider-item__info-id">ID 9968</div>
<div class="slider-item__info-users">
<i class="icon-partners icon-left"></i> 111 </div>
</div>
</div>
<div class="slider-item-stats">
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in USD</div>
<div class="slider-item__block-info">$ 197710</div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in TRX</div>
<div class="slider-item__block-info">2326000 <span>TRX</span></div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Registration date</div>
<div class="slider-item__block-info">12-09-2022</div>
</div>
</div>
</div>
</div>
<div class="slider-item eth-item">
<div class="slider-item-content">
<div class="slider-item__info">

<img src="assets/images/logo/favicon-logo.png?updated=1665123465" width="120" alt="">
<div class="slider-item__info-text">
<div class="slider-item__info-id">ID 2445</div>
<div class="slider-item__info-users">
<i class="icon-partners icon-left"></i> 64 </div>
</div>
</div>
<div class="slider-item-stats">
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in USD</div>
<div class="slider-item__block-info">$ 188491.75</div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in TRX</div>
<div class="slider-item__block-info">2217550 <span>TRX</span></div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Registration date</div>
<div class="slider-item__block-info">12-09-2022</div>
</div>
</div>
</div>
</div>
<div class="slider-item eth-item">
<div class="slider-item-content">
<div class="slider-item__info">

<img src="assets/images/logo/favicon-logo.png?updated=1665123465" width="120" alt="">
<div class="slider-item__info-text">
<div class="slider-item__info-id">ID 361</div>
<div class="slider-item__info-users">
<i class="icon-partners icon-left"></i> 9 </div>
</div>
</div>
<div class="slider-item-stats">
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in USD</div>
<div class="slider-item__block-info">$ 170283.9</div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in TRX</div>
<div class="slider-item__block-info">2003340 <span>TRX</span></div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Registration date</div>
<div class="slider-item__block-info">11-09-2022</div>
</div>
</div>
</div>
</div>
<div class="slider-item eth-item">
<div class="slider-item-content">
<div class="slider-item__info">

<img src="assets/images/logo/favicon-logo.png?updated=1665123465" width="120" alt="">
<div class="slider-item__info-text">
<div class="slider-item__info-id">ID 15145</div>
<div class="slider-item__info-users">
<i class="icon-partners icon-left"></i> 91 </div>
</div>
</div>
<div class="slider-item-stats">
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in USD</div>
<div class="slider-item__block-info">$ 136573.75</div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in TRX</div>
<div class="slider-item__block-info">1606750 <span>TRX</span></div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Registration date</div>
<div class="slider-item__block-info">13-09-2022</div>
</div>
</div>
</div>
</div>
<div class="slider-item eth-item">
<div class="slider-item-content">
<div class="slider-item__info">

<img src="assets/images/logo/favicon-logo.png?updated=1665123465" width="120" alt="">
<div class="slider-item__info-text">
<div class="slider-item__info-id">ID 4420</div>
<div class="slider-item__info-users">
<i class="icon-partners icon-left"></i> 39 </div>
</div>
</div>
<div class="slider-item-stats">
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in USD</div>
<div class="slider-item__block-info">$ 126009.95</div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Earnings in TRX</div>
<div class="slider-item__block-info">1482470 <span>TRX</span></div>
</div>
<div class="slider-item__block">
<div class="slider-item__block-title">Registration date</div>
<div class="slider-item__block-info">12-09-2022</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-lg-1 el-desc results-slider-btn-wrapper">
<button class="results-slider-btn results-slider-btn-next">
<svg width="28" height="54" viewBox="0 0 28 54" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M27.7071 26.2929C28.0976 26.6834 28.0976 27.3166 27.7071 27.7071L1.7071 53.7071C1.31658 54.0976 0.683415 54.0976 0.292891 53.7071C-0.0976326 53.3166 -0.0976326 52.6834 0.292891 52.2929L26.2929 26.2929C26.6834 25.9024 27.3166 25.9024 27.7071 26.2929Z" fill="white" />
<path fill-rule="evenodd" clip-rule="evenodd" d="M27.7071 27.7071C27.3166 28.0976 26.6834 28.0976 26.2929 27.7071L0.292892 1.70711C-0.0976315 1.31658 -0.0976315 0.683416 0.292892 0.292892C0.683416 -0.0976323 1.31658 -0.0976323 1.70711 0.292892L27.7071 26.2929C28.0976 26.6834 28.0976 27.3166 27.7071 27.7071Z" fill="white" />
</svg>
</button>
</div>
</div>
<div class="results-stat">
<div class="results-stat-list" id="results-1">
<div class="row">
<div class="col-lg-6 results-stat-item-wrapper">
<div class="results-stat-item align-items-center">
<span class="results-stat-item-num">
<nobr class="text-color-1">56255</nobr>
<span class="results-stat-item-num-plus">
<nobr>+ 689</nobr>
</span>
 </span>
<span class="results-stat-item-text text-color-1">Number of accounts</span>
</div>
</div>
<div class="col-lg-6 results-stat-item-wrapper">
<div class="results-stat-item align-items-center">
<span class="results-stat-item-num">
<span class="mr-3 text-color-1">$ 26,685,428</span> <nobr></nobr>
</span>
<span class="results-stat-item-text text-color-1">Total turnover, USD</span>
</div>
</div>
</div>
</div>

</div>
</div>
</div>
<div class="section calculator">
<div class="container">
<div class="calculator-list-wrapper">
<div class="calculator-header">
<span class="section-title"><span class="text-gradient">Ox Cash</span> Income
Calculator </span>
<span class="section-subtitle mb-0">
Estimate your potential results from Ox Cash by selecting the amount
of slots. The totals are indicated for 1 cycle of all selected slots. <br> * All
calculations are for informational purposes only and are not an offer. </span>
<div class="calculator-list-title d-none">
<div class="row">
<div class="col-lg-6">
<div class="calculator-list-platforms">
<button class="btn btn-mini calculator-list-btn active" id="calc-btn-1" data-token="TRX" onclick=opencalc(1)><i class="icon-TRX"></i></button>
<button class="btn btn-mini calculator-list-btn" id="calc-btn-2" data-token="redrhino" onclick=opencalc(2)><i class="icon-eth"></i></button>
<button class="btn btn-mini calculator-list-btn" id="calc-btn-3" data-token="TRX" onclick=opencalc(3)><i class="icon-trx"></i></button>
</div>
</div>
</div>
</div>
</div>
<div class="calculator-list">

<div class="calculator-list-item" id="calculator-list-item-1">
<div class="row">
<div class="col-lg-12 m-auto">
<div class="calculator-item calculator-item-soon " id="calc-xGold">
<div class="calculator-head">
<div class="calculator-logo justify-content-start justify-content-md-center">
<h4 class="text-center text-light">Ox Cash</h4>


</div>
<span class="calculator-dropdown-btn btn align-items-center justify-content-center">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white" />
</svg>
</span>
</div>
<div class="row">
<div class="col-lg-6 d-flex">
<div class="calculator-item-levels">
<button class="calculatorPage-level" data-lprice="200"> 1
</button>
<button class="calculatorPage-level" data-lprice="400"> 2
</button>
<button class="calculatorPage-level" data-lprice="800"> 3
</button>
<button class="calculatorPage-level" data-lprice="1600"> 4
</button>
<button class="calculatorPage-level" data-lprice="3200"> 5
</button>
<button class="calculatorPage-level" data-lprice="6400"> 6
</button>
<button class="calculatorPage-level" data-lprice="12800"> 7
</button>
<button class="calculatorPage-level" data-lprice="25000"> 8
</button>
<button class="calculatorPage-level" data-lprice="50000"> 9
</button>
<button class="calculatorPage-level" data-lprice="100000"> 10
</button>
<button class="calculatorPage-level" data-lprice="200000"> 11
</button>
<button class="calculatorPage-level" data-lprice="400000"> 12
</button>
<button class="calculatorPage-level" data-lprice="800000"> 13
</button>
<button class="calculatorPage-level" data-lprice="1500000"> 14
</button>
<button class="calculatorPage-level" data-lprice="3000000"> 15
</button>
</div>
</div>
<div class="col-lg-6">
<span class="calculator-item-soon-text">New Ox Cash Program is
here!</span>
<div class="calculator-item-text">
Exclusive program with maximum opportunities for teamwork and development. </div>
<div class="calculator-item-total el-desc">
<div class="calculator-item-total-wrapper">
<div class="calculator-item-total-title">Cost of all
selected slots</div>
<div class="calculator-item-total-sum" id="total-sum">
<div class="calculator-item-total-token-wrapper"><span class="calculator-item-total-token">0</span>TRX
</div>
<div class="calculator-item-total-fiat-wrapper">$<span class="calculator-item-total-fiat">0</span>
</div>
</div>
</div>
<div class="calculator-item-total-wrapper">
<div class="calculator-item-total-title">Total results in 1
cycle from selected slots</div>
<div class="calculator-item-total-sum" id="total-cycle">
<div class="calculator-item-total-token-wrapper"><span class="calculator-item-total-token">0</span>TRX
</div>
<div class="calculator-item-total-fiat-wrapper">$<span class="calculator-item-total-fiat">0</span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<input class="calculator-token" type="hidden" value="1">
</div>
</div>
</div>
</div>
</div>
</div>

<section class="light-bg-1 bottom-padding-0 top-padding-120" hidden data-midnight="black">

<div data-animation-container class="container small bottom-padding-60 text-center">
<h2 data-animation-child class="large-title text-height-10 text-color-1 overlay-anim-box2" data-animation="overlay-anim2">Ox Blogs</h2><br>
<p data-animation-child class="fade-anim-box tr-delay02 text-color-1 xsmall-title-oswald top-margin-5" data-animation="fade-anim">Learn about ox cash</p>
</div>

<div class="bottom-padding-0">

<div class="portfolio-content flex-min-height-box">

<div class="portfolio-content-inner flex-min-height-inner">

<div class="flex-container reverse container small">

<div class="six-columns top-padding-60">
<div class="portfolio-content-bg-box pointer-large hover-box hidden-box">
<div class="portfolio-content-bg hover-img overlay-anim-box2 overlay-dark-bg-2" data-animation="overlay-anim2" style="background-image:url(assets/images/admin/1651356687web-1-04.jpg)"></div>
</div>
</div>

<div data-animation-container class="six-columns">
<div class="content-left-margin-40">
<h3 class="title-style text-color-1">
<span data-animation-child class="overlay-anim-box2 overlay-dark-bg-2 tr-delay01" data-animation="overlay-anim2">ZERO RISK</span>
</h3>
<p data-animation-child class="p-style-small text-color-2 fade-anim-box tr-delay04" data-animation="fade-anim">Oxcash developers conveyed a self-executing savvy contract on Tron Blockchain.</p>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="bottom-padding-0">

<div class="portfolio-content flex-min-height-box">

<div class="portfolio-content-inner flex-min-height-inner">

<div class="flex-container container small">

<div data-animation-container class="six-columns">
<div class="content-right-margin-40">
<h3 class="title-style text-color-1">
<span data-animation-child class="overlay-anim-box2 overlay-dark-bg-2 tr-delay01" data-animation="overlay-anim2">BUSHWICK SELFIES PORK BELLY LYFT BROOKLYN MESSENG</span>
</h3>
<p data-animation-child class="p-style-small text-color-2 fade-anim-box tr-delay04" data-animation="fade-anim">Narwhal pop-up intelligentsia tbh pinterest, microdosing tilde cloud bread gochujang tattooed leggings cornhole 8-bit. Austin fam chia cold-pressed raw denim. Glossier drinking vinegar portland lo-fi, polaroid bespoke lomo. Banjo art party XOXO, fashion axe sustainable retro ethical gentrify. </p>
</div>
</div>

<div class="six-columns top-padding-60">
<div class="portfolio-content-bg-box pointer-large hover-box hidden-box">
<div class="portfolio-content-bg hover-img overlay-anim-box2 overlay-dark-bg-2" data-animation="overlay-anim2" style="background-image:url(assets/images/admin/16513143942.jpg)"></div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="bottom-padding-0">

<div class="portfolio-content flex-min-height-box">

<div class="portfolio-content-inner flex-min-height-inner">

<div class="flex-container reverse container small">

<div class="six-columns top-padding-60">
<div class="portfolio-content-bg-box pointer-large hover-box hidden-box">
<div class="portfolio-content-bg hover-img overlay-anim-box2 overlay-dark-bg-2" data-animation="overlay-anim2" style="background-image:url(assets/images/admin/16513143993.jpg)"></div>
</div>
</div>

<div data-animation-container class="six-columns">
<div class="content-left-margin-40">
<h3 class="title-style text-color-1">
<span data-animation-child class="overlay-anim-box2 overlay-dark-bg-2 tr-delay01" data-animation="overlay-anim2">BUSHWICK SELFIES PORK BELLY LYFT BROOKLYN MESSENG</span>
</h3>
<p data-animation-child class="p-style-small text-color-2 fade-anim-box tr-delay04" data-animation="fade-anim">Narwhal pop-up intelligentsia tbh pinterest, microdosing tilde cloud bread gochujang tattooed leggings cornhole 8-bit. Austin fam chia cold-pressed raw denim. Glossier drinking vinegar portland lo-fi, polaroid bespoke lomo. Banjo art party XOXO, fashion axe sustainable retro ethical gentrify. </p>
</div>
</div>
</div>
</div>
</div>
</div>
</section>

<div class="section factors dark-bg-1 top-bottom-padding-120 will-animate">
<div class="container">
<div data-animation-container="" class="container small bottom-padding-60 text-center animated">
<h2 data-animation-child="" class="large-title text-height-10 text-color-4 overlay-anim-box2 animated overlay-anim2" data-animation="overlay-anim2">Perfect Technology</h2><br>
<p data-animation-child="" class="fade-anim-box tr-delay02 text-color-5 xsmall-title-oswald top-margin-5 animated fade-anim" data-animation="fade-anim">Decentralized marketing programs are powered by revolutionary smart contract technology. The OxCash smart contract code is <span class="text-white">completely publicly available</span> . You can be confident in its safety and long-term success. </p>
</div>
<div class="factors-wrapper el-desc">
<div class="row">
<div class="col-lg-6 offset-lg-1">
<div class="factors-cards">
<div class="factors-card factors-card-desk" id="factors-card-1">
<div class="factors-card-icon">
<svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M15 4.74976C9.33908 4.74976 4.75 9.33884 4.75 14.9998C4.75 20.6607 9.33908 25.2498 15 25.2498C20.6609 25.2498 25.25 20.6607 25.25 14.9998C25.25 9.33884 20.6609 4.74976 15 4.74976ZM2.75 14.9998C2.75 8.23427 8.23451 2.74976 15 2.74976C21.7655 2.74976 27.25 8.23427 27.25 14.9998C27.25 21.7652 21.7655 27.2498 15 27.2498C8.23451 27.2498 2.75 21.7652 2.75 14.9998Z" fill="white"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M10.25 12.4998C10.25 11.9475 10.6977 11.4998 11.25 11.4998H11.2625C11.8148 11.4998 12.2625 11.9475 12.2625 12.4998C12.2625 13.052 11.8148 13.4998 11.2625 13.4998H11.25C10.6977 13.4998 10.25 13.052 10.25 12.4998Z" fill="white"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M17.75 12.4998C17.75 11.9475 18.1977 11.4998 18.75 11.4998H18.7625C19.3148 11.4998 19.7625 11.9475 19.7625 12.4998C19.7625 13.052 19.3148 13.4998 18.7625 13.4998H18.75C18.1977 13.4998 17.75 13.052 17.75 12.4998Z" fill="white"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M11.1751 18.0355C11.5696 17.649 12.2028 17.6554 12.5893 18.0499C12.9035 18.3706 13.2786 18.6254 13.6926 18.7994C14.1065 18.9733 14.551 19.0629 15 19.0629C15.449 19.0629 15.8935 18.9733 16.3075 18.7994C16.7214 18.6254 17.0965 18.3706 17.4107 18.0499C17.7972 17.6554 18.4304 17.649 18.8249 18.0355C19.2193 18.422 19.2258 19.0551 18.8393 19.4496C18.3388 19.9604 17.7415 20.3662 17.0822 20.6432C16.423 20.9202 15.7151 21.0629 15 21.0629C14.2849 21.0629 13.577 20.9202 12.9178 20.6432C12.2585 20.3662 11.6612 19.9604 11.1607 19.4496C10.7742 19.0551 10.7807 18.422 11.1751 18.0355Z" fill="white"></path>
</svg>
</div>
<div class="factors-card-title">Autonomous</div>
<div class="factors-card-desc">The Ox Cash ecosystem is built on the smart
contract technology that is completely autonomous, which excludes human
factor.</div>
</div>
<div class="factors-card factors-card-desk" id="factors-card-2" hidden="">
<div class="factors-card-icon">
<svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M17.5 2.75C18.0523 2.75 18.5 3.19772 18.5 3.75V8.75C18.5 8.8163 18.5263 8.87989 18.5732 8.92678C18.6201 8.97366 18.6837 9 18.75 9H23.75C24.3023 9 24.75 9.44771 24.75 10C24.75 10.5523 24.3023 11 23.75 11H18.75C18.1533 11 17.581 10.7629 17.159 10.341C16.7371 9.91903 16.5 9.34674 16.5 8.75V3.75C16.5 3.19772 16.9477 2.75 17.5 2.75Z" fill="white"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M8.75 4.75C8.35217 4.75 7.97064 4.90804 7.68934 5.18934C7.40804 5.47064 7.25 5.85217 7.25 6.25V10C7.25 10.5523 6.80228 11 6.25 11C5.69772 11 5.25 10.5523 5.25 10V6.25C5.25 5.32174 5.61875 4.4315 6.27513 3.77513C6.9315 3.11875 7.82174 2.75 8.75 2.75H17.5C17.7652 2.75 18.0196 2.85536 18.2071 3.04289L24.4571 9.29289C24.6446 9.48043 24.75 9.73478 24.75 10V23.75C24.75 24.6783 24.3812 25.5685 23.7249 26.2249C23.0685 26.8813 22.1783 27.25 21.25 27.25H15C14.4477 27.25 14 26.8023 14 26.25C14 25.6977 14.4477 25.25 15 25.25H21.25C21.6478 25.25 22.0294 25.092 22.3107 24.8107C22.592 24.5294 22.75 24.1478 22.75 23.75V10.4142L17.0858 4.75H8.75Z" fill="white"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M7.5 14.75C5.98122 14.75 4.75 15.9812 4.75 17.5C4.75 19.0188 5.98122 20.25 7.5 20.25C9.01878 20.25 10.25 19.0188 10.25 17.5C10.25 15.9812 9.01878 14.75 7.5 14.75ZM2.75 17.5C2.75 14.8766 4.87665 12.75 7.5 12.75C10.1234 12.75 12.25 14.8766 12.25 17.5C12.25 20.1234 10.1234 22.25 7.5 22.25C4.87665 22.25 2.75 20.1234 2.75 17.5Z" fill="white"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M5.91239 20.2922C6.44138 20.4509 6.74157 21.0084 6.58287 21.5374L5.37291 25.5706L7.05283 24.7306C7.33436 24.5898 7.66573 24.5898 7.94726 24.7306L9.62717 25.5706L8.41722 21.5374C8.25852 21.0084 8.5587 20.4509 9.0877 20.2922C9.61669 20.1335 10.1742 20.4337 10.3329 20.9627L12.2079 27.2127C12.3225 27.5948 12.199 28.0085 11.8937 28.2653C11.5884 28.5221 11.1597 28.5729 10.8028 28.3945L7.50004 26.7431L4.19726 28.3945C3.84042 28.5729 3.41168 28.5221 3.10636 28.2653C2.80104 28.0085 2.67758 27.5948 2.79222 27.2127L4.66722 20.9627C4.82591 20.4337 5.3834 20.1335 5.91239 20.2922Z" fill="white"></path>
</svg>
</div>
<div class="factors-card-title">Immutable conditions</div>
<div class="factors-card-desc">Blockchain secures the algorithm, therefore
nobody, even the authors of the idea, can interfere, cancel, or alter your
transactions. </div>
</div>
<div class="factors-card factors-card-desk" id="factors-card-3" hidden="">
<div class="factors-card-icon">
<svg width="30" height="31" viewBox="0 0 30 31" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M15 13.5034C14.1716 13.5034 13.5 14.175 13.5 15.0034C13.5 15.8318 14.1716 16.5034 15 16.5034C15.8284 16.5034 16.5 15.8318 16.5 15.0034C16.5 14.175 15.8284 13.5034 15 13.5034ZM11.5 15.0034C11.5 13.0704 13.067 11.5034 15 11.5034C16.933 11.5034 18.5 13.0704 18.5 15.0034C18.5 16.9364 16.933 18.5034 15 18.5034C13.067 18.5034 11.5 16.9364 11.5 15.0034Z" fill="white"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M3.65815 15.0034C6.67853 20.0576 10.2622 22.5135 14.3723 22.7365C14.9238 22.7665 15.3466 23.2378 15.3167 23.7892C15.2868 24.3407 14.8155 24.7635 14.264 24.7336C9.11024 24.4539 4.91373 21.2427 1.63177 15.4996C1.45608 15.1921 1.45608 14.8147 1.63177 14.5073C5.07395 8.48376 9.51999 5.25342 15 5.25342C20.48 5.25342 24.9261 8.48376 28.3682 14.5073C28.5438 14.8145 28.5439 15.1917 28.3685 15.499C27.8263 16.4492 27.2585 17.3287 26.6682 18.1352C26.3421 18.5809 25.7164 18.6778 25.2707 18.3517C24.825 18.0255 24.7281 17.3998 25.0543 16.9541C25.4942 16.353 25.9242 15.7027 26.342 15.0036C23.1745 9.70295 19.3854 7.25342 15 7.25342C10.6146 7.25342 6.82559 9.7029 3.65815 15.0034Z" fill="white"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M26.9571 20.5463C27.3476 20.9368 27.3476 21.57 26.9571 21.9605L21.9571 26.9605C21.7696 27.1481 21.5152 27.2534 21.25 27.2534C20.9848 27.2534 20.7304 27.1481 20.5429 26.9605L18.0429 24.4605C17.6524 24.07 17.6524 23.4368 18.0429 23.0463C18.4334 22.6558 19.0666 22.6558 19.4571 23.0463L21.25 24.8392L25.5429 20.5463C25.9334 20.1558 26.5666 20.1558 26.9571 20.5463Z" fill="white"></path>
</svg>
</div>
<div class="factors-card-title">Transparent</div>
<div class="factors-card-desc">The smart contract code is open, and anyone
anytime can observe the entire transaction history. This ensures fair
conditions and trustworthy statictics to rely on. </div>
</div>
<div class="factors-card factors-card-desk" id="factors-card-4" hidden="">
<div class="factors-card-icon">
<svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M6.01145 5.02854C6.66783 4.37217 7.55807 4.00342 8.48633 4.00342H20.9863C21.5831 4.00342 22.1554 4.24047 22.5773 4.66243C22.9993 5.08439 23.2363 5.65668 23.2363 6.25342V9.00342H23.4863C24.0831 9.00342 24.6554 9.24047 25.0773 9.66243C25.4993 10.0844 25.7363 10.6567 25.7363 11.2534V15.0034C25.7363 15.5557 25.2886 16.0034 24.7363 16.0034C24.184 16.0034 23.7363 15.5557 23.7363 15.0034V11.2534C23.7363 11.1871 23.71 11.1235 23.6631 11.0766C23.6162 11.0298 23.5526 11.0034 23.4863 11.0034H8.48633C7.96249 11.0034 7.45076 10.886 6.98633 10.6657V22.5034C6.98633 22.9012 7.14436 23.2828 7.42567 23.5641C7.70697 23.8454 8.0885 24.0034 8.48633 24.0034H23.4863C23.5526 24.0034 23.6162 23.9771 23.6631 23.9302C23.71 23.8833 23.7363 23.8197 23.7363 23.7534V20.0034C23.7363 19.4511 24.184 19.0034 24.7363 19.0034C25.2886 19.0034 25.7363 19.4511 25.7363 20.0034V23.7534C25.7363 24.3502 25.4993 24.9224 25.0773 25.3444C24.6554 25.7664 24.0831 26.0034 23.4863 26.0034H8.48633C7.55807 26.0034 6.66783 25.6347 6.01145 24.9783C5.35508 24.3219 4.98633 23.4317 4.98633 22.5034V7.50342C4.98633 6.57516 5.35508 5.68492 6.01145 5.02854ZM6.98633 7.50342C6.98633 7.90124 7.14436 8.28277 7.42567 8.56408C7.70697 8.84538 8.0885 9.00342 8.48633 9.00342H21.2363V6.25342C21.2363 6.18711 21.21 6.12353 21.1631 6.07664C21.1162 6.02976 21.0526 6.00342 20.9863 6.00342H8.48633C8.0885 6.00342 7.70697 6.16145 7.42567 6.44276C7.14436 6.72406 6.98633 7.10559 6.98633 7.50342Z" fill="white"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M20.9863 16.0034C20.5885 16.0034 20.207 16.1615 19.9257 16.4428C19.6444 16.7241 19.4863 17.1056 19.4863 17.5034C19.4863 17.9012 19.6444 18.2828 19.9257 18.5641C20.207 18.8454 20.5885 19.0034 20.9863 19.0034H24.9863V16.0034H20.9863ZM18.5115 15.0285C19.1678 14.3722 20.0581 14.0034 20.9863 14.0034H25.9863C26.5386 14.0034 26.9863 14.4511 26.9863 15.0034V20.0034C26.9863 20.5557 26.5386 21.0034 25.9863 21.0034H20.9863C20.0581 21.0034 19.1678 20.6347 18.5115 19.9783C17.8551 19.3219 17.4863 18.4317 17.4863 17.5034C17.4863 16.5752 17.8551 15.6849 18.5115 15.0285Z" fill="white"></path>
</svg>
</div>
<div class="factors-card-title">Fully automatic</div>
<div class="factors-card-desc">All transactions between the community members
are executed directly from one personal wallet to another.</div>
</div>
<div class="factors-card factors-card-desk" id="factors-card-5" hidden="">
<div class="factors-card-icon">
<svg width="30" height="31" viewBox="0 0 30 31" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M6.25 21.0034C5.42157 21.0034 4.75 21.675 4.75 22.5034C4.75 23.3318 5.42157 24.0034 6.25 24.0034C7.07843 24.0034 7.75 23.3318 7.75 22.5034C7.75 21.675 7.07843 21.0034 6.25 21.0034ZM2.75 22.5034C2.75 20.5704 4.317 19.0034 6.25 19.0034C8.183 19.0034 9.75 20.5704 9.75 22.5034C9.75 24.4364 8.183 26.0034 6.25 26.0034C4.317 26.0034 2.75 24.4364 2.75 22.5034Z" fill="white"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M23.75 6.00342C22.9216 6.00342 22.25 6.67499 22.25 7.50342C22.25 8.33185 22.9216 9.00342 23.75 9.00342C24.5784 9.00342 25.25 8.33185 25.25 7.50342C25.25 6.67499 24.5784 6.00342 23.75 6.00342ZM20.25 7.50342C20.25 5.57042 21.817 4.00342 23.75 4.00342C25.683 4.00342 27.25 5.57042 27.25 7.50342C27.25 9.43641 25.683 11.0034 23.75 11.0034C21.817 11.0034 20.25 9.43641 20.25 7.50342Z" fill="white"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M23.75 9.00342C24.3023 9.00342 24.75 9.45113 24.75 10.0034V16.2534C24.75 18.1762 23.9862 20.0203 22.6265 21.3799C21.2669 22.7396 19.4228 23.5034 17.5 23.5034H16.1642L18.2071 25.5463C18.5976 25.9368 18.5976 26.57 18.2071 26.9605C17.8166 27.3511 17.1834 27.3511 16.7929 26.9605L13.0429 23.2105C12.6524 22.82 12.6524 22.1868 13.0429 21.7963L16.7929 18.0463C17.1834 17.6558 17.8166 17.6558 18.2071 18.0463C18.5976 18.4368 18.5976 19.07 18.2071 19.4605L16.1642 21.5034H17.5C18.8924 21.5034 20.2277 20.9503 21.2123 19.9657C22.1969 18.9812 22.75 17.6458 22.75 16.2534V10.0034C22.75 9.45113 23.1977 9.00342 23.75 9.00342Z" fill="white"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M11.7929 3.04631C12.1834 2.65579 12.8166 2.65579 13.2071 3.04631L16.9571 6.79631C17.1446 6.98385 17.25 7.2382 17.25 7.50342C17.25 7.76863 17.1446 8.02299 16.9571 8.21053L13.2071 11.9605C12.8166 12.351 12.1834 12.351 11.7929 11.9605C11.4024 11.57 11.4024 10.9368 11.7929 10.5463L13.8358 8.50342H12.5C11.1076 8.50342 9.77226 9.05654 8.78769 10.0411C7.80312 11.0257 7.25 12.361 7.25 13.7534V20.0034C7.25 20.5557 6.80228 21.0034 6.25 21.0034C5.69772 21.0034 5.25 20.5557 5.25 20.0034V13.7534C5.25 11.8306 6.01384 9.98653 7.37348 8.62689C8.73311 7.26726 10.5772 6.50342 12.5 6.50342H13.8358L11.7929 4.46052C11.4024 4.07 11.4024 3.43684 11.7929 3.04631Z" fill="white"></path>
</svg>
</div>
<div class="factors-card-title">Decentralized</div>
<div class="factors-card-desc">There are no managers or admins at the head, the
creators are the same platform participants like everyone else.</div>
</div>
<div class="factors-card factors-card-desk" id="factors-card-6" hidden="">
<div class="factors-card-icon">
<svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M15.9863 11.0034C15.5885 11.0034 15.207 11.1615 14.9257 11.4428C14.6444 11.7241 14.4863 12.1056 14.4863 12.5034V17.5034C14.4863 17.9012 14.6444 18.2828 14.9257 18.5641C15.207 18.8454 15.5885 19.0034 15.9863 19.0034C16.3842 19.0034 16.7657 18.8454 17.047 18.5641C17.3283 18.2828 17.4863 17.9012 17.4863 17.5034V12.5034C17.4863 12.1056 17.3283 11.7241 17.047 11.4428C16.7657 11.1615 16.3842 11.0034 15.9863 11.0034ZM15.9863 9.00342C16.9146 9.00342 17.8048 9.37217 18.4612 10.0285C19.1176 10.6849 19.4863 11.5752 19.4863 12.5034V17.5034C19.4863 18.4317 19.1176 19.3219 18.4612 19.9783C17.8048 20.6347 16.9146 21.0034 15.9863 21.0034C15.0581 21.0034 14.1678 20.6347 13.5115 19.9783C12.8551 19.3219 12.4863 18.4317 12.4863 17.5034V12.5034C12.4863 11.5752 12.8551 10.6849 13.5115 10.0285C14.1678 9.37217 15.0581 9.00342 15.9863 9.00342Z" fill="white"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M15.9863 4.75342C10.3254 4.75342 5.73633 9.3425 5.73633 15.0034C5.73633 20.6643 10.3254 25.2534 15.9863 25.2534C21.6472 25.2534 26.2363 20.6643 26.2363 15.0034C26.2363 9.3425 21.6472 4.75342 15.9863 4.75342ZM3.73633 15.0034C3.73633 8.23793 9.22084 2.75342 15.9863 2.75342C22.7518 2.75342 28.2363 8.23793 28.2363 15.0034C28.2363 21.7689 22.7518 27.2534 15.9863 27.2534C9.22084 27.2534 3.73633 21.7689 3.73633 15.0034Z" fill="white"></path>
</svg>
</div>
<div class="factors-card-title">100% in the network</div>
<div class="factors-card-desc">No hidden expences or service fees. The contract
balance is always zero.</div>
</div>
</div>
</div>
<div class="col-lg-5 el-desc">
<div class="factors-btns">
<button onclick="clickcard(1)" class="factors-btn active" id="factors-btn-1">
<div class="factors-btn-progress" style="width: 100%;"></div>Autonomous
</button>
<button onclick="clickcard(2)" class="factors-btn" id="factors-btn-2">
<div class="factors-btn-progress" style="width: 100%;"></div>Immutable conditions
</button>
<button onclick="clickcard(3)" class="factors-btn" id="factors-btn-3">
<div class="factors-btn-progress" style="width: 100%;"></div>Transparent
</button>
<button onclick="clickcard(4)" class="factors-btn" id="factors-btn-4">
<div class="factors-btn-progress" style="width: 100%;"></div>Fully automatic
</button>
<button onclick="clickcard(5)" class="factors-btn" id="factors-btn-5">
<div class="factors-btn-progress" style="width: 100%;"></div>Decentralized
</button>
<button onclick="clickcard(6)" class="factors-btn" id="factors-btn-6">
<div class="factors-btn-progress" style="width: 100%;"></div>100% in the network
</button>
</div>
</div>
</div>
</div>
</div>
</div>


<section class="dark-bg-2">

<div class="container small top-bottom-padding-120">

<h2 data-animation-container class="medium-title text-center">
<span data-animation-child class="title-fill" data-animation="title-fill-anim" data-text="OX Cash Worldwide">OX Cash Worldwide</span><br>
</h2>

<ul class="client-list d-flex-wrap top-padding-60">
<li>
<a href="" aria-disabled="true" class="pointer-large d-block">
<div class="brand-box">
<img src="assets/images/admin/thailand.png" style="" alt="" class="">
<p class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim">Thailand</p>

</div>
</a>
</li>
<li>
<a href="" aria-disabled="true" class="pointer-large d-block">
<div class="brand-box">
<img src="assets/images/admin/india.png" style="" alt="" class="">
<p class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim">India</p>

</div>
</a>
</li>
<li>
<a href="" aria-disabled="true" class="pointer-large d-block">
<div class="brand-box">
<img src="assets/images/admin/pakistan.png" style="" alt="" class="">
<p class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim">Pakistan</p>

</div>
</a>
</li>
<li>
<a href="" aria-disabled="true" class="pointer-large d-block">
<div class="brand-box">
<img src="assets/images/admin/turkey.png" style="" alt="" class="">
<p class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim">Turkey</p>

</div>
</a>
</li>
<li>
<a href="" aria-disabled="true" class="pointer-large d-block">
<div class="brand-box">
<img src="assets/images/admin/east-african.png" style="" alt="" class="">
<p class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim">East Africa</p>

</div>
</a>
</li>
<li>
<a href="" aria-disabled="true" class="pointer-large d-block">
<div class="brand-box">
<img src="assets/images/admin/united-arab-emirates.png" style="" alt="" class="">
<p class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim">UAE</p>

</div>
</a>
</li>
<li>
<a href="" aria-disabled="true" class="pointer-large d-block">
<div class="brand-box">
<img src="assets/images/admin/vietnam.png" style="" alt="" class="">
<p class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim">Vietnam</p>

</div>
</a>
</li>
<li>
<a href="" aria-disabled="true" class="pointer-large d-block">
<div class="brand-box">
<img src="assets/images/admin/cambodia.png" style="" alt="" class="">
<p class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim">Cambodia</p>

</div>
</a>
</li>
</ul>
</div>
</section>
<div class="section faq dark-bg-1 top-bottom-padding-120 will-animate">
<div class="container">
<div data-animation-container="" class="container small bottom-padding-60 text-center animated">
<h2 data-animation-child="" class="large-title text-height-10 text-color-4 overlay-anim-box2 animated overlay-anim2" data-animation="overlay-anim2">Frequently asked Questions</h2>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
WHAT IS OX.CASH? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">Ox.Cash is the international community of the global decentralized ecosystem and the first ever Tron smart contract marketing matrix.</p>
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">
This is a self-executing software algorithm that performs the function of distributing partner rewards between community members, subject to certain conditions (matrix marketing plan). The contract code is publicly available. Information about transactions can always be viewed at the link tronscan.org .</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
WHO MANAGES THE PLATFORM? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">The Ox.Cash platform consists of self-executing trades, which do not permit anyone to interfere with the course of the transactions.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
WHO CREATED OX.CASH? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">The Ox.Cash concept belongs to a group of crypto enthusiasts, who are members of the community and don’t have any special privileges.</p>
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">Today, Ox.Cash is an peer-to-peer community of platform members, to whom the platform itself belongs.</p>
</div>
</div>
</div>
<div class="accordion-wrap" hidden="">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
WHAT IS TRON? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
 </svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">Tron (TRX) is one of the leading cryptocurrency, which has existed since 2017. At the same time, it is a software framework for the DeFi (decentralized finance) market, since the blockchain of this crypto currency allows you not only to follow the history of transactions, but also to save any executable software products (smart contracts). A huge number of major crypto companies use this platform.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
WHAT IS A SMART CONTRACT? WHAT ARE ITS ADVANTAGES? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">A smart contract is an algorithm within a cryptocurrency’s blockchain. In our case, Tron is our first choice among those on which it is possible to create smart contracts. The main purpose of such contracts is the automation of the relationship, the opportunity to make a commitment self-executing.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
WHAT IS DECENTRALIZATION? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">The process works based on distributing authority from a centralized administration to the participants involved in the process. Unlike a centralized system, all decisions are made by consensus.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
WHICH WALLET SHOULD I USE? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">Ox.Cash works with all crypto wallets. We recommend the following:</p>
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">- for mobile devices (smartphone, tablet) the app TronLink Wallet <a href="https://tronlink.org" target="_blank" rel="noopener noreferrer">https://tronlink.org</a></p>
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">- Token Pocket Wallet (can be used in China) <a href="https://www.tokenpocket.pro/" target="_blank" rel="noopener noreferrer">https://www.tokenpocket.pro/</a></p>
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">for computers and laptops browser extension Tronlink <a href="https://www.tronlink.org/" target="_blank" rel="noopener noreferrer">https://www.tronlink.org/</a></p>
</div>
 </div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
WHAT DO I NEED TO DO TO CREATE A TRON WALLET? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">To register you will need only a wallet Tronlink - a Google Chrome extension (PC) and/or some other applications for mobile devices. Tested and safe applications:</p>
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">- wallet Tron Wallet <a href="https://www.tronwallet.me/" target="_blank" rel="noopener noreferrer">https://www.tronwallet.me/</a></p>
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">- Token Pocket Wallet <a href="https://www.tokenpocket.pro/" target="_blank" rel="noopener noreferrer">https://www.tokenpocket.pro/</a></p>
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">When registering don't forget to securely and safely store the password for your wallet.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
HOW TO BUY/SELL TRON IF I’VE NEVER DEALT WITH CRYPTOCURRENCIES BEFORE? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">There are lots of ways to buy/sell cryptocurrencies in exchange for fiat money (regular currencies). They have all been designed for regular users and have user-friendly interfaces. Your first transaction exchanging fiat money for digital currency will take you no more than five minutes. We recommend using the verified currency exchange aggregator.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
HOW CAN I REGISTER ON THE OX.CASH PLATFORM? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">To register with Ox.Cash you needs to send 200 TRX to the smart contract in order to activate the platforms. The transaction itself constitutes your registration on the platform.</p>
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">Please note: when topping up a crypto wallet, you need to account for the network’s commission, which is usually about 10 TRX.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
CAN I REGISTER ON THE WEBSITE WITHOUT A PARTNER LINK? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">Yes. Registering without an invitation link will put you in team.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
WHAT WILL HAPPEN TO MY ACCOUNT IF I TAKE A BREAK FROM WORKING WITH THE OX.CASH COMMUNITY? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">No one can close your account, even if they have a strong desire to do so. The account will always be saved in one of the Tron network blocks. You will continue to receive income from all levels, except the last active one.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
I HAVE ACTIVATED THE PLATFORM, WHAT SHOULD I DO NEXT? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">In order to effectively interact with the Ox.Cash platform, you need to:</p>
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">- Have a chat with whoever invited you or with other experienced members. They will help you take your first steps.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
HOW CAN I REACH MY GOALS WITH OX.CASH? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">It is based on building a partner network. You tell potential partners about the platform’s potential and encourage them to collaborate with you. Partners who use your link send their first transactions to the smart contract address, and these are then instantly redirected to your wallet. The platform works directly with three marketing plans.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
IS PASSIVE INCOME POSSIBLE? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">The Ox.Cash platform have been built in such a way that all members of the system help one another. Passive income is possible; it depends on the activity of partners, who can end up on your platform via overflows or overtakes.</p>
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">You can get overflows from higher-ranked or lower-ranked partners, however your income will depend on their activity. In order to ensure that you have a passive income in the future, you need to make a determined effort to attract new partners and open new platforms in.</p>
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">Once you have invited even a single active person onto your team, you can already earn good money and achieve your goals. How quickly this happens depends solely on you.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
HOW CAN I ATTRACT PEOPLE EFFECTIVELY? WHAT SHOULD I DO IF I CAN’T ATTRACT ANYONE? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim"> You don’t have to force anyone to take part. Currently, lots of people are interested in how to earn money on the internet, and some of them are actively seeking new opportunities. You can meet them on social networks yourself, or you could set up an automatic sales funnel, such that anyone who is interested will find you themselves. </p>
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">Take advantage of your own strengths, watch webinars, ask questions to experiences platform members and you won’t have to wait long to succeed. Your results depend solely on you!</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
HOW MUCH CAN I EARN? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">The amount of income depends on the quality indicators of your activity and the activities of your partners.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
DO I NEED TO WITHDRAW MONEY FROM OX.CASH? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">Ox.Cash does not retain any funds, so the balance of the smart contract is equal to zero. Your income arrives instantly into your personal wallet directly from your partners. Only you have access to your wallet and no one else can manage your money.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
DO LEVELS HAVE A VALIDITY PERIOD? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">No. Purchasing any level in the program occurs one time and lasts forever. Levels do not have a validity period.This distinguishes the Ox.Cash platform from other projects, which require repeated payments.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
WHAT IS REPEAT (RE-OPENING)? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">If there are no free places left on a level, then the next partner gets a place in an automatically created matrix of the same level. This is called Repeat. The partner who took the last place pays for the new matrix, and the amount goes to a higher-ranked partner. This process is entirely automated by the smart contract.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
WHAT ARE \OVERFLOWS\" AND \"OVERTAKES\"?" <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">Overflows are when free places in your platforms are taken by partners whom you yourself didn’t invite. They can come from a higher-ranked or lower-ranked partners. </p>
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">An overtake is a situation when one of your partners hasn’t reached the level that their partner is activating, and thus the transaction is sent along the chain to you, on the condition that you have this level active. This partner follows you and provides you income, as long as their higher-ranked partner has not activated the missing levels.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
CAN I LOSE PARTNER WHOM I HAVE PERSONALLY INVITED? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
 <div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">No. It is not possible.Any partner whom you have invited personally is permanently bound to you by the referral link.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
HOW DOES THIS DIFFER FROM A PYRAMID SCHEME? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">Because it does not make any unfulfillable promises to its members. Each person’s success depends on themselves. Ox.Cash will remain stable even if it increases in size a thousandfold. Ox.Cash does not create debts or other obligations.</p>
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">Ox.Cash is a next-gen crowdfunding platform and has nothing to do with pyramid schemes.</p>
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">The principle of a pyramid scheme is that a large portion of the money is concentrated in the hands of its creators. The earlier you arrive, the more you earn. A pyramid scheme can be closed at any time. Members of the Ox.Cash platform, both leaders and newcomers, are on equal terms. No one can terminate the platform’s operation, since its functionality is ensured by a smart contract, which cannot be erased or altered. Even if the website ceases to function, all the data and the entire structure will remain intact, and the smart contract will continue to function, as long as there is electricity and internet access.</p>
</div>
</div>
</div>
<div class="accordion-wrap">
<div class="accordion revealator-slideright revealator-once revealator-within">
<div class="accordion-heading">
WHAT ARE THE RISKS? <span class="accordion-heading__arrow btn btn-purple">
<svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M0.292969 1.70718L1.70718 0.292969L7.00007 5.58586L12.293 0.292971L13.7072 1.70718L7.00007 8.41429L0.292969 1.70718Z" fill="white"></path>
</svg>
</span>
</div>
<div class="accordion-content">
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">There are no risks on the Ox.Cash platform. You just need to invite one person to recoup your initial membership expense. The platform works on the basis of a smart contract in a blockchain system. The code for the smart contract is in the public domain.</p>
<p data-animation-child="" class="p-style-medium text-color-5 fade-anim-box tr-delay02 animated fade-anim" data-animation="fade-anim">All transfers go straight to your personal wallet, without any hidden commissions and without using any third-party resources. This guarantees that any amount that you earn belongs to you and you alone, and you can use the money as you like as soon as it arrives in your wallet.</p>
</div>
</div>
</div>
</div>
</div>



</main>

<footer class="footer dark-bg-1">

<div class="flex-container container top-bottom-padding-90">

<div class="two-columns bottom-padding-60">
<div class="content-right-margin-10 footer-center-mobile">
<img src="https://ox.cash/logo.png" alt="logo">
</div>
</div>

<div class="ten-columns bottom-padding-60">
<div class="content-left-margin-10">
<ul class="footer-social text-right">
<li>
<div class="flip-btn-box">
<a href="#" class="flip-btn pointer-small" data-text="Telegram">Telegram</a>
</div>
</li>
<li>
<div class="flip-btn-box">
<a href="#" class="flip-btn pointer-small" data-text="Twitter">Twitter</a>
</div>
</li>
<li>
<div class="flip-btn-box">
<a href="#" class="flip-btn pointer-small" data-text="Facebook">Facebook</a>
</div>
</li>
</ul>
</div>
</div>
<div class="twelve-columns">
<p class="p-letter-style text-color-4 footer-copyright">&copy; Copyright 2022 | OX CASH</p>
</div>
</div>
</footer>

<script src="assets/js/plugins.js?updated=1665123465"></script>
<script src="assets/js/main.js?updated=1665123465"></script>

<script defer src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script src="assets/js/common.js?updated=1665123465"></script>

<script type="text/javascript">
			var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
			(function(){
				var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
				s1.async=true;
				s1.src='https://embed.tawk.to/626955edb0d10b6f3e6fa0a3/default';
				s1.charset='UTF-8';
				s1.setAttribute('crossorigin','*');
				s0.parentNode.insertBefore(s1,s0);
			})();
		<!--End of Tawk.to Script-->
        </script>
<script>
			if(document.querySelector('.factors') && window.screen.width > 992 ) {

				factorsProgress(1);

				function opencard(id){
					var el = document.getElementById('factors-card-'+id);
					var btn = document.getElementById('factors-btn-'+id);

					if(el.hidden){
						document.querySelectorAll('.factors-btn').forEach(item => item.classList.remove('active'));
						document.querySelectorAll('.factors-card-desk').forEach(item => item.hidden = true);
						btn.classList.add('active');
						factorsProgress(id);
						el.hidden = false;
					}
					
				}

				function clickcard(id){
					var el = document.getElementById('factors-card-'+id);
					var btn = document.getElementById('factors-btn-'+id);

					function factorsProgress() { }

					if(el.hidden){
						document.querySelectorAll('.factors-btn').forEach(item => item.classList.remove('active'));
						document.querySelectorAll('.factors-card-desk').forEach(item => item.hidden = true);
						btn.classList.add('active');
						el.hidden = false;
					}
					
				}

				function factorsProgress(id){
					var time = setInterval(start,75);
					var btns = document.getElementsByClassName('factors-btn').length;
					var elem = document.querySelector(".factors-btn.active .factors-btn-progress");
					var width = 20;

					function start() {        
						if (width > 100) {
							if (id < btns) {
								id = id + 1;
								clearInterval(time);
								opencard(id);
							}
							else {
								clearInterval(time);
							} 
						} else {  
							elem.style.width = width + '%'; 
							width++;
						}
					}
					function stop() {

					}

				}
				}

				$('.factors-cards.owl-carousel').owlCarousel({
				autoplay: true,
				autoplayTimeout: 50000,
				smartSpeed: 500, 
				items:1,
				margin: 20,
				loop: true,
				nav: false,
				dots: true,
				});
		</script>
<script>
			// accordion
			if (document.querySelector('.faq')) {
				! function (i) {
					var o, n;
					i(".accordion-heading").on("click", function () {
						o = i(this).parents(".accordion"), n = o.find(".accordion-content"),
							o.hasClass("active") ? (o.removeClass("active"),
								n.slideUp()) : (o.addClass("active"), n.stop(!0, !0).slideDown(),
								o.siblings(".active").removeClass("active").children(".accordion-content").stop(!0, !0).slideUp());
					})
				}(jQuery);
			}
		</script>

<script>
			
			const modal = document.querySelector(".modal-box");
			const trigger = document.querySelector(".trigger");
			const closeButton = document.querySelector(".close-button");

			function toggleModal() {
				modal.classList.toggle("show-modal");
				// $('body').toggleClass("overflow-hidden")
			}

			function windowOnClick(event) {
				if (event.target === modal) {
					toggleModal();
				}
			}

			trigger.addEventListener("click", toggleModal);
			closeButton.addEventListener("click", toggleModal);
			window.addEventListener("click", windowOnClick);
		</script>


<script>
			$(function() { // Dropdown toggle
				$('.dropdown-toggle').click(function() { 
					$(this).next('.dropdown-box').slideToggle();
				});

				$(document).click(function(e) 
				{ 
					var target = e.target; 
					if (!$(target).is('.dropdown-toggle') && !$(target).parents().is('.dropdown-toggle')) 
					//{ $('.dropdown').hide(); }
					{ $('.dropdown-box').slideUp(); }
				});
			});
		</script>

</body>
</html>